Завдання на тему DOM(Document Object Model)

Почергово виконуйте завдання які знаходяться у файлах
task1.js -> task2.js -> task3.js -> task4.js
